# import speech_recognition as sr
# r = sr.Recognizer()


# with sr.Microphone() as source:
#     r.adjust_for_ambient_noise(source)
#     data = r.record(source, duration=5)
#     print("selva")
#     text = r.recognize_google(data,language='en')
#     print(text)


# import speech_recognition as sr
# import numpy as np
# r = sr.Recognizer()
# from guessing_game  import recognize_speech_from_mic

# r = sr.Recognizer()
# m = sr.Microphone()
# g=recognize_speech_from_mic(r, m) 
# print(g)

# from moviepy.editor import *
# audioclip = AudioFileClip("some_audiofile.mp3")

# import pyttsx3
# def speak(message):
#     engine=pyttsx3.init()
#     rate=engine.g>>> etProperty('rate')
#     engine.setProperty('rate',rate-10)
#     engine.say('Google says {}'.format(message))
#     engine.runAndWait()


# import speech_recognition as sr
# import pyttsx3

# r=sr.Recognizer()
# mic=sr.Microphone(device_index=1)




# from audioplayer import AudioPlayer

# AudioPlayer("Hihowcanhelp.mp3").play(block=True)
## Intial Camera On 

from moviepy.editor import *
audioclip = AudioFileClip("Hihowcanhelp.mp3")
audioclip.fps = 44100
audioclip.preview()
## what is your good name:
audioclip = AudioFileClip("what is your good name.mp3")
audioclip.fps = 44100
audioclip.preview()
## From Mic Input
import speech_recognition as sr
import numpy as np
# r = sr.Recognizer()
from guessing_game  import recognize_speech_from_mic

r = sr.Recognizer()
m = sr.Microphone()
g=recognize_speech_from_mic(r, m) 
txt=g["transcription"]
# gx={'success': True, 'error': None, 'transcription': 'hello camera on hello hello hello'} 
# print(type(txt),g)
# txt='Hi what is your good name......'
from gtts import gTTS
file = r"/home/selva/Selva/Products/Task/Voic/voice/Selva.mp3"
tts = gTTS(str(txt))
tts.save(file)
print('end user name',str(txt))
### Again call end user name 
end_user_name=txt
in_text='Hi ......'
ful_txt=os.path.join(in_text,end_user_name)

from gtts import gTTS
file = r"fulltxt.mp3"

tts = gTTS(str(ful_txt))
tts.save(file)

# Play 

audioclip = AudioFileClip("fulltxt.mp3")
audioclip.fps = 44100
audioclip.preview()

## Camera Setup for end user
Stat='B'
dis_text=[]
if Stat=='A':
    print('Go back small distance')
    dis_text='Go back small distance'
elif Stat=='B':
    print('Come forward small distance')
    dis_text='Come forward small distance'
else :
    print('Stand here')

ful_txt=os.path.join(dis_text,end_user_name)

from gtts import gTTS
file = r"dis_text.mp3"

tts = gTTS(str(ful_txt))
tts.save(file)
# Play 

audioclip = AudioFileClip("dis_text.mp3")
audioclip.fps = 44100
audioclip.preview()


###############


####################Working Audio to text
# import speech_recognition as sr
# import numpy as np
# # r = sr.Recognizer()
# from guessing_game  import recognize_speech_from_mic

# r = sr.Recognizer()
# m = sr.Microphone()
# g=recognize_speech_from_mic(r, m) 
# txt=g["transcription"]
# gx={'success': True, 'error': None, 'transcription': 'hello camera on hello hello hello'} 
# print(type(txt),g)
# txt='Hi what is your good name......'
# from gtts import gTTS
# file = r"/home/selva/Selva/Products/Task/Voic/voice/what is your good name.mp3"

# tts = gTTS(str(txt))
# tts.save(file)